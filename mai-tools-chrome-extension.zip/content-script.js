(() => {
  const marker = "data-mai-tools-extension";
  if (document.documentElement.hasAttribute(marker)) {
    return;
  }

  document.documentElement.setAttribute(marker, "chrome");

  const scriptUrl = chrome.runtime.getURL("all-in-one.js");
  const script = document.createElement("script");
  script.src = scriptUrl;
  script.dataset.source = "mai-tools-chrome-extension";
  script.onload = () => script.remove();
  (document.body || document.documentElement).append(script);
})();
